prompt PL/SQL Developer import file
prompt Created on 2020��3��4�� by qiubing
set feedback off
set define off
prompt Disabling triggers for ELEMENTSOFCONTROL...
alter table ELEMENTSOFCONTROL disable all triggers;
prompt Disabling triggers for FORMELEMENT...
alter table FORMELEMENT disable all triggers;
prompt Loading ELEMENTSOFCONTROL...
insert into ELEMENTSOFCONTROL (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('krisk', 'insuyearAXA', null, null, null, 30, '01', 'AXA@SCI', null, null);
insert into ELEMENTSOFCONTROL (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('krisk', 'payendyearAXA', null, null, null, 40, '01', 'AXA@SCI', null, null);
insert into ELEMENTSOFCONTROL (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('krisk', 'payintvAXA', null, null, null, 50, '01', 'AXA@SCI', null, null);
insert into ELEMENTSOFCONTROL (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('krisk', 'premAXA', null, null, null, 20, '01', 'AXA@SCI', null, null);
insert into ELEMENTSOFCONTROL (SID, ID, DEFAULTVALUE, VALIDITEM, RELATEOBJECTFIELD, COMORDER, ELEMENTSTATUS, COMBINEDID, SUBSID, CSSCLASS)
values ('krisk', 'risknameAXA', null, null, null, 10, '01', 'AXA@SCI', null, 'disabled');
commit;
prompt 5 records loaded
prompt Loading FORMELEMENT...
insert into FORMELEMENT (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, CSSCLASS, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('krisk', 'insuyearAXA', 'insuyear', '�����ڼ�', 'combobox', null, 'commonCombobox_insuyears', null, 'lcpol', null, null);
insert into FORMELEMENT (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, CSSCLASS, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('krisk', 'payendyearAXA', 'payendyear', '�ɷ��ڼ�', 'combobox', null, 'commonCombobox_payendyears', null, 'lcpol', null, null);
insert into FORMELEMENT (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, CSSCLASS, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('krisk', 'payintvAXA', 'payintv', '�ɷѷ�ʽ', 'combobox', null, 'commonCombobox_payintvs', null, 'lcpol', null, null);
insert into FORMELEMENT (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, CSSCLASS, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('krisk', 'premAXA', 'prem', '����', 'text', null, null, null, 'lcpol', null, null);
insert into FORMELEMENT (SID, ID, NAME, TEXT, TYPE, ENGLISHTEXT, CHECKBOXOPTION, CSSCLASS, GROUPID, PARENTID, NOTICEELEMENTGROUP)
values ('krisk', 'risknameAXA', 'riskname', '��Ʒ����', 'text', null, null, null, 'lcpol', null, null);
commit;
prompt 5 records loaded
prompt Enabling triggers for ELEMENTSOFCONTROL...
alter table ELEMENTSOFCONTROL enable all triggers;
prompt Enabling triggers for FORMELEMENT...
alter table FORMELEMENT enable all triggers;
set feedback on
set define on
prompt Done.
